package com.maniu.hook

class MyClass {
}