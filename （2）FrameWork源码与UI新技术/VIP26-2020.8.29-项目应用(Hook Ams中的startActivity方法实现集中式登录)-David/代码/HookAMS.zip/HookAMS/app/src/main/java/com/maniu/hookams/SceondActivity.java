package com.maniu.hookams;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by 48608 on 2018/1/12.
 */

public class SceondActivity extends Activity {
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }
}
