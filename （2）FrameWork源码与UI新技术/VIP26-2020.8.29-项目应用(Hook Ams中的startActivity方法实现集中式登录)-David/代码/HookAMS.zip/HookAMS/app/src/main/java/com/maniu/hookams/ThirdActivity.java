package com.maniu.hookams;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Administrator on 2018/2/26 0026.
 */

public class ThirdActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thrid);
    }
}
