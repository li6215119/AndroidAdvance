package com.maniu.notchscreenmaniu.screen.interfaces;

import com.maniu.notchscreenmaniu.screen.NotchProperty;

public interface OnNotchCallBack {
    void onNotchPropertyCallback(  NotchProperty notchProperty);
}
