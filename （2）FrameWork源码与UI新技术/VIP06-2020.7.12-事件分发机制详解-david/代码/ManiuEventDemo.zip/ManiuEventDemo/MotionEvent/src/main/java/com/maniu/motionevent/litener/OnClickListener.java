package com.maniu.motionevent.litener;

import com.maniu.motionevent.View;

public interface OnClickListener {
    void onClick(View v);
}