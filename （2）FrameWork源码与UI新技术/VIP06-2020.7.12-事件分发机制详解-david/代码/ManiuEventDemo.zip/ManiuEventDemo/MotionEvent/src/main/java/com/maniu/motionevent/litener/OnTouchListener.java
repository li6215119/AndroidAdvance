package com.maniu.motionevent.litener;


import com.maniu.motionevent.MotionEvent;
import com.maniu.motionevent.View;

public interface OnTouchListener {
    boolean onTouch(View v, MotionEvent event);
}
