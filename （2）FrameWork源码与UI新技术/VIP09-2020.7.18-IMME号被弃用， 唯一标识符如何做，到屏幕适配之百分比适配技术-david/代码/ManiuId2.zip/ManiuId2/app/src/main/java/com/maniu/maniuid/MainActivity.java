package com.maniu.maniuid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        文件   ---》
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "--->  " + DeviceIdUtil.getDeviceId(this), Toast.LENGTH_SHORT).show();

    }
}