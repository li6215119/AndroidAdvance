package com.mnviphandler;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    // 在子线程处理handler的时候
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        new Thread(new Runnable() {
            @Override
            public void run() {
            Looper.prepare();
            Handler handler = new Handler(){
                @Override
                public void handleMessage(@NonNull Message msg) {

                    super.handleMessage(msg);
                }
            };
            handler.sendEmptyMessage(1);
            Looper.loop();
        }
    }).start();
    }

}
