package com.maniu.pmsmniu;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.Nullable;
//IBinder   强联系通信 方式 侯敏会讲的   防止
public class ServiceDavie extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
