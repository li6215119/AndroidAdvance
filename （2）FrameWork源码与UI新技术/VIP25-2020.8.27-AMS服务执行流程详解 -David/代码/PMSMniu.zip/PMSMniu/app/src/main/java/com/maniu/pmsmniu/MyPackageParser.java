package com.maniu.pmsmniu;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

import dalvik.system.DexClassLoader;

public class MyPackageParser {
    public    void parserReceivers(Context context, File apkFile) throws Exception {
        /**
         *  PackageParser pp = new PackageParser();
         *  pr.pkg = parsePackage(pp, scanFile, parseFlags);
         *  pms解析一个apk的过程
         *  应用也想解析    解析apk    换肤   热修复   插件
         */
        Class<?> packageParserClass = Class.forName("android.content.pm.PackageParser");
//        8.0  9.0  10.0  优化了很多
        Method parsePackageMethod = packageParserClass.getDeclaredMethod("parsePackage", File.class, int.class,boolean.class);
        Object packageParser = packageParserClass.newInstance();
        parsePackageMethod.setAccessible(true);

//  pp.parsePackage(Fil);适配
        Object packageObj = parsePackageMethod.invoke(packageParser, apkFile, PackageManager.GET_RECEIVERS, false);
        Field receiversField = packageObj.getClass().getDeclaredField("receivers");

        List receivers = (List) receiversField.get(packageObj);
//        recervers  拉出来    然后动态注册这个广播    下载下了
//dex加载的优化
        DexClassLoader dexClassLoader = new DexClassLoader(apkFile.getAbsolutePath(),
                context.getDir("plugin", Context.MODE_PRIVATE).getAbsolutePath(),
                null, context.getClassLoader());
// 99号
        Class<?> componentClass = Class.forName("android.content.pm.PackageParser$Component");

        Field intentsField = componentClass.getDeclaredField("intents");


///ActivityInfo   -----  BroadcastReceiver
//
//
// com.maniu.receive.DavidReceiver  类名怎么获取     david  采取


        for (Object receiverObject : receivers) {
            String name = (String) receiverObject.getClass().getField("className").get(receiverObject);
            Class clazz=dexClassLoader.loadClass(name);
            List<? extends IntentFilter> filters = (List<? extends IntentFilter>) intentsField.get(receiverObject);
            for (IntentFilter filter : filters) {
                BroadcastReceiver broadcastReceiver = (BroadcastReceiver) clazz.newInstance();
                context.registerReceiver(broadcastReceiver, filter);
            }
        }
    }

}
