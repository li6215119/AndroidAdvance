#include <jni.h>
#include <string>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>
int8_t *m_ptr;
int32_t m_size;
int m_fd;
extern "C"
JNIEXPORT void JNICALL
Java_com_maniu_mmkvdemo_Binder_writeTest(JNIEnv *env, jobject thiz) {
    std::string file = "/storage/emulated/0/a.txt";
    m_fd = open(file.c_str(), O_RDWR | O_CREAT, S_IRWXU);
//    获得一页内存
//Linux采用分页来管理内存，即内存管理内存已页为单位，
    m_size = getpagesize();
//将文件设置成 m_size 大小
    ftruncate(m_fd, m_size);
    m_ptr = static_cast<int8_t *>(mmap(0, m_size, PROT_READ | PROT_WRITE,
            MAP_SHARED, m_fd, 0));

    std::string data("快扶我去大保健");
    memcpy(m_ptr, data.data(), data.size());
}