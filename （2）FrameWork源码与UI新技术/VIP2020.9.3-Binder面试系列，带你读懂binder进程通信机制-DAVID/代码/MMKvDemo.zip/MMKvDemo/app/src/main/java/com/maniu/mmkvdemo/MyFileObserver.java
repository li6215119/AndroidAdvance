package com.maniu.mmkvdemo;

import android.os.FileObserver;
import android.util.Log;

public class MyFileObserver extends FileObserver {

    //如此构造的对象监听所有FileObserver可以监听的事件，path为需监听的文件路径
    public MyFileObserver(String path) {
        super(path);
    }
    //这样构造的对象只监听mask对应的事件
    public MyFileObserver(String path, int mask) {
        super(path, mask);
    }
    //需要实现的方法（当触发监听事件时系统会自动回调该方法）
    @Override
    public void onEvent(int event, String path) {
        Log.i("david", "onEvent: "+event);
        switch (event) {
            case FileObserver.CREATE:
                //执行的逻辑
                break;
            case FileObserver.DELETE:
                //执行的逻辑
                break;
        }

    }
}
