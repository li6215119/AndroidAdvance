package com.maniu.mmkvdemo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileObserver;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.

    Binder binder = new Binder();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FileObserver fileObserver = new MyFileObserver(new File(Environment.getExternalStorageDirectory(), "a.txt").toString());
        fileObserver.startWatching();
        getSystemService(CONNECTIVITY_SERVICE);
//        File file = new File();
        startService(new Intent());

    }

    public void writer(View view) {
        binder.writeTest();
    }

    public void read(View view) {

    }
}
