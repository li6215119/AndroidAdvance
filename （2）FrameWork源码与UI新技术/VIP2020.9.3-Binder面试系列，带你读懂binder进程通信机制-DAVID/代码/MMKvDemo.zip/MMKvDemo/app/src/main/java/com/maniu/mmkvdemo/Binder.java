package com.maniu.mmkvdemo;

public class Binder {

    static {
        System.loadLibrary("native-lib");
    }
    public native void writeTest();
}
