package com.maniu.maniuanimator.animator;

public interface TimeInterpolator {
    float getInterpolation(float input);
}
