package com.maniu.maniuanimator;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;

import com.maniu.maniuanimator.animator.MyObjectAnimator;
import com.maniu.maniuanimator.animator.TimeInterpolator;

public class MainActivity extends AppCompatActivity {
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.btn);
    }

//    public void scale(View view) {
////
//         ObjectAnimator objectAnimator =  ObjectAnimator.
//                ofFloat(button, "scaleX", 1f,2f);
//        objectAnimator.setDuration(3000);
//        objectAnimator.start();
//         ObjectAnimator objectAnimator2 =  ObjectAnimator.
//                ofFloat(button, "scaleY", 1f,2f);
//        objectAnimator2.setDuration(3000);
//        objectAnimator2.start();
//    }
    public void scale(View view) {
        MyObjectAnimator objectAnimator = MyObjectAnimator.
                ofFloat(button, "scaleX", 1f, 2f);
        objectAnimator.setDuration(3000);
        objectAnimator.setInterpolator(new TimeInterpolator() {
            @Override
            public float getInterpolation(float input) {
                return (float)(Math.cos((input + 1) * Math.PI) / 2.0f) + 0.5f;
            }
        });
        objectAnimator.start();
        MyObjectAnimator objectAnimator2 = MyObjectAnimator.
                ofFloat(button, "scaleY", 1f, 2f);
        objectAnimator2.setDuration(3000);
        objectAnimator2.setInterpolator(new TimeInterpolator() {
            @Override
            public float getInterpolation(float input) {
                return (float)(Math.cos((input + 1) * Math.PI) / 2.0f) + 0.5f;
            }
        });
        objectAnimator2.start();
    }
//
//
////
////        objectAnimator2.setInterpolator(new TimeInterpolator() {
////            @Override
////            public float getInterpolation(float input) {
////                return (float)(Math.cos((input + 1) * Math.PI) / 2.0f) + 0.5f;
////            }
////        });
//    }

}