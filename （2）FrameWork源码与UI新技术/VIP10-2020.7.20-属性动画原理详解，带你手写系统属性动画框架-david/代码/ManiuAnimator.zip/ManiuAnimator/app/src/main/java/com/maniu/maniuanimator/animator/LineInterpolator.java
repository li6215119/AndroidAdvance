package com.maniu.maniuanimator.animator;

public class    LineInterpolator implements  TimeInterpolator {
    @Override
    public float getInterpolation(float input) {
        return input;
    }
}
