package com.maniu.receive;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class DavidReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, " 2插件:我是插件广播，收到你的信息了", Toast.LENGTH_SHORT).show();
        Intent intent1 =new Intent();
        intent.setAction("com.maniu.receiver2");
        context.sendBroadcast(intent1);
    }
}
