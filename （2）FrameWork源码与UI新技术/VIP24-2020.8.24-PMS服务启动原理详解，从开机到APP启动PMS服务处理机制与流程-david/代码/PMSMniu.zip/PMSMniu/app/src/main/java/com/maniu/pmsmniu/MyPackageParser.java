package com.maniu.pmsmniu;

import android.content.Context;
import android.content.pm.PackageManager;

import java.io.File;
import java.lang.reflect.Method;

public class MyPackageParser {
    public    void parserReceivers(Context context, File apkFile) throws Exception {

        /**
         *  PackageParser pp = new PackageParser();
         *   pr.pkg = parsePackage(pp, scanFile, parseFlags);
         */
        Class<?> packageParserClass = Class.forName("android.content.pm.PackageParser");
        Method parsePackageMethod = packageParserClass.getDeclaredMethod("parsePackage", File.class, int.class);
        Object packageParser = packageParserClass.newInstance();

//  pp.parsePackage(Fil);适配
        Object packageObj = parsePackageMethod.invoke(packageParser, apkFile, PackageManager.GET_RECEIVERS);
        packageObj.hashCode();
    }

}
