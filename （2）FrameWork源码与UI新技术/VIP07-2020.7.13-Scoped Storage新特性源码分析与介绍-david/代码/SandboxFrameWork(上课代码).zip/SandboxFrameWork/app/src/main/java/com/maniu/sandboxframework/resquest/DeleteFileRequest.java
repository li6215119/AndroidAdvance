package com.maniu.sandboxframework.resquest;

public class DeleteFileRequest {
}
