package com.maniu.sandboxframework.resquest;

import android.content.ContentValues;
import android.net.Uri;

import java.io.File;

public class CopyFileRequest {
    /**
     * 需要删除的文件： 必传参数  mFile（"Download/David"）
     */
    private File mFile;
    /**
     * 目标文件，必传参数
     */
    private File mTargetFile;

    private String mMediaId;
    private ContentValues mContentValues;
    private Uri mContentUri;

    public CopyFileRequest(File file) {
        mFile = file;
    }

    public File getFile() {
        return mFile;
    }

    public void setmFile(File mFile) {
        this.mFile = mFile;
    }

    public ContentValues getmContentValues() {
        return mContentValues;
    }

    public void setmContentValues(ContentValues mContentValues) {
        this.mContentValues = mContentValues;
    }

    public Uri getmContentUri() {
        return mContentUri;
    }

    public void setmContentUri(Uri mContentUri) {
        this.mContentUri = mContentUri;
    }
}
