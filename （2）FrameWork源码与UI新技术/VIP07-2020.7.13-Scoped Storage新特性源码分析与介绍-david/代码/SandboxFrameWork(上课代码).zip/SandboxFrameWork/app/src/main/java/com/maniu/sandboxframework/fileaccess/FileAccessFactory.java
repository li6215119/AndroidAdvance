package com.maniu.sandboxframework.fileaccess;

import android.os.Environment;

import com.maniu.sandboxframework.meadia.MediaStoreAccessImp;

public class FileAccessFactory {
//    FileAccessInterface   实现类 有沙箱实现类    普通的实现类
    public static FileAccessInterface getCreateFileAccess(String filePath) {
        if (isSandbox()) {
            return MediaStoreAccessImp.getInstance() ;
        }else {
            return FileAccessImp.getInstance() ;
        }
    }
    private static boolean isSandbox() {
        return !Environment.isExternalStorageLegacy();
    }
}
