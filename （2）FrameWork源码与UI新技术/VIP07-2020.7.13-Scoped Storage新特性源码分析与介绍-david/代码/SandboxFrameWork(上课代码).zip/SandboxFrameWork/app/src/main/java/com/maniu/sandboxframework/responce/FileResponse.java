package com.maniu.sandboxframework.responce;

import android.net.Uri;

import java.io.File;

public class FileResponse {
    private boolean mIsSuccess;
    private Uri mUri;
    private File mFile;
    public boolean ismIsSuccess() {
        return mIsSuccess;
    }

    public void setmIsSuccess(boolean mIsSuccess) {
        this.mIsSuccess = mIsSuccess;
    }

    public Uri getmUri() {
        return mUri;
    }

    public void setmUri(Uri mUri) {
        this.mUri = mUri;
    }

    public File getmFile() {
        return mFile;
    }

    public void setmFile(File mFile) {
        this.mFile = mFile;
    }
}
