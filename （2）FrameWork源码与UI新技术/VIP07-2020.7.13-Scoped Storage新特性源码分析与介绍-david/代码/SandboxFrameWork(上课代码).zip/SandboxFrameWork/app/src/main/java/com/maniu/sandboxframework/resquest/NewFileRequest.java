package com.maniu.sandboxframework.resquest;

import android.content.ContentValues;
import android.net.Uri;

import java.io.File;

public class NewFileRequest {
    /**
     * 需要删除的文件： 必传参数  mFile（"Download/David"）  路径的字符串  ----->Download
     * picture  dcim
     * video
     * music
     * 路径
     */
    private File mFile;

    private ContentValues mContentValues;
    private Uri mContentUri;

    public NewFileRequest(File file) {
        mFile = file;
    }

    public File getFile() {
        return mFile;
    }

    public void setmFile(File mFile) {
        this.mFile = mFile;
    }

    public ContentValues getContentValues() {
        return mContentValues;
    }

    public void setmContentValues(ContentValues mContentValues) {
        this.mContentValues = mContentValues;
    }

    public Uri getContentUri() {
        return mContentUri;
    }

    public void setmContentUri(Uri mContentUri) {
        this.mContentUri = mContentUri;
    }
}
