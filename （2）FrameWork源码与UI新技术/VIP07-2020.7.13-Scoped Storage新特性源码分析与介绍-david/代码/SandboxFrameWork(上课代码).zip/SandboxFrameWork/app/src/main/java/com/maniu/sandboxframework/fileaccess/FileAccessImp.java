package com.maniu.sandboxframework.fileaccess;

import android.content.Context;
import android.os.ParcelFileDescriptor;

import com.maniu.sandboxframework.responce.FileResponse;
import com.maniu.sandboxframework.resquest.CopyFileRequest;
import com.maniu.sandboxframework.resquest.DeleteFileRequest;
import com.maniu.sandboxframework.resquest.NewFileRequest;
import com.maniu.sandboxframework.resquest.OpenFileRequest;
import com.maniu.sandboxframework.resquest.RenameToFileRequest;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FileAccessImp implements FileAccessInterface {
    private static final String TAG = "FileAccessImp";
    private static FileAccessImp sInstance;

    private FileAccessImp() {

    }

    public static FileAccessImp getInstance() {
        if (sInstance == null) {
            synchronized (FileAccessImp.class) {
                if (sInstance == null) {
                    sInstance = new FileAccessImp();
                }
            }
        }
        return sInstance;
    }
    @Override
    public ParcelFileDescriptor openFile(Context context, OpenFileRequest request) throws FileNotFoundException {
        return null;
    }

    @Override
    public FileResponse newCreateFile(Context context, NewFileRequest request) {
        if ((request == null) || (request.getFile() == null)) {

            return null;
        }
        File file = request.getFile();
        boolean result = true;
        try {
            File parnetFile = file.getParentFile();
            if (!parnetFile.exists()) {
                parnetFile.mkdirs();
            }
            result = file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileResponse fileResponse = new FileResponse();
        fileResponse.setmIsSuccess(result);
        return fileResponse;
    }

    @Override
    public boolean delete(Context context, DeleteFileRequest request) {
        return false;
    }

    @Override
    public FileResponse renameTo(Context context, RenameToFileRequest renameRequest) {
        return null;
    }

    @Override
    public boolean mkdirs(Context context, File file) {
        return false;
    }

    @Override
    public InputStream getInputStream(Context context, OpenFileRequest request) throws FileNotFoundException {
        return null;
    }

    @Override
    public OutputStream getOutStream(Context context, OpenFileRequest request) throws FileNotFoundException {
        return null;
    }

    @Override
    public boolean copyFile(Context context, CopyFileRequest copyFileRequest) {
        return false;
    }
}
