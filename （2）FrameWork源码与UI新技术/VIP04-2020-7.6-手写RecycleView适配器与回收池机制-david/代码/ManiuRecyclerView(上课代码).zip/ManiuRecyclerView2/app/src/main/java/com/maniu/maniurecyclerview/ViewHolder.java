package com.maniu.maniurecyclerview;

import android.view.View;

public class ViewHolder {
//    itemView跟布局
    public View itemView;
    int mItemViewType = -1;

    public ViewHolder(View itemView) {
        this.itemView = itemView;
    }

    public int getmItemViewType() {
        return mItemViewType;
    }

    public void setmItemViewType(int mItemViewType) {
        this.mItemViewType = mItemViewType;
    }
}
