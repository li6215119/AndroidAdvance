package com.maniu.mmapdavid;

public class Binder {
    static {
        System.loadLibrary("native-lib");
    }


    public native void binde_open();
}
