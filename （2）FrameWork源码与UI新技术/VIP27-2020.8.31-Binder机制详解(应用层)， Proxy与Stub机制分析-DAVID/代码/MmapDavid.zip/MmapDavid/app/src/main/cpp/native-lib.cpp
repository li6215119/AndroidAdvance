#include <jni.h>
#include <string>
#import <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
extern "C"
JNIEXPORT void JNICALL
Java_com_maniu_mmapdavid_Binder_binde_1open(JNIEnv *env, jobject thiz) {
//    dev/binder

    std::string file = "/storage/emulated/0/david.txt";

    int m_fd=open(file.c_str(), O_RDWR | O_CREAT, S_IRWXU);
//    映射 大小    4K  就是一页   磁盘    4k 4k

//读取一页
    int32_t m_size = getpagesize();
//    文件设置 大小  4K
    ftruncate(m_fd, m_size);
    int8_t *m_ptr= static_cast<int8_t *>(mmap(0, m_size, PROT_READ | PROT_WRITE, MAP_SHARED, m_fd,
                                              0));
//    1  binder



    std::string data("快扶我去大保健");
    memcpy(m_ptr, data.data(), data.size());

    close(m_fd);

//    物理内存  m_ptr
}