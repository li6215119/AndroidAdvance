package com.maniu.hashmaniu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
//16   12    32
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        HashMap map=new HashMap(65);
        map.put("","")
//        16 *2    128
//        hashmap   >

    }
}
