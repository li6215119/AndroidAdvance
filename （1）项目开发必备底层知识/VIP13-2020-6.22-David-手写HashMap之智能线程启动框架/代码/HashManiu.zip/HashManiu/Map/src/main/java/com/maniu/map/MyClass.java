package com.maniu.map;

import java.util.HashMap;

public class MyClass {
//    64
    HashMap hashMap = new HashMap(44);

    public static void main(String[] args) {
        ManiuHashMap maniuHashMap = new ManiuHashMap<String, String>(14);
        maniuHashMap.put("1号", "苍井空");// 0
        maniuHashMap.put("2号", "林志玲");// 1
        maniuHashMap.put("3号", "林雯雯");// 2
        maniuHashMap.put("4号", "4号");// 3
        maniuHashMap.put("6号", "6号");// 4
        maniuHashMap.put("7号", "7号");//5
        maniuHashMap.put("14号", "14号");//6
        maniuHashMap.print();
        System.out.println(maniuHashMap.get("3号"));
    }
    static final int MAXIMUM_CAPACITY = 1 << 30;

    static final int tableSizeFor(int cap) {
        int n = cap - 1;
         n= n| n >>> 1;
        n |= n >>> 2;
        n |= n >>> 4;
        n |= n >>> 8;
        n |= n >>> 16;
        return (n < 0) ? 1 : (n >= MAXIMUM_CAPACITY) ? MAXIMUM_CAPACITY : n + 1;
    }


}
