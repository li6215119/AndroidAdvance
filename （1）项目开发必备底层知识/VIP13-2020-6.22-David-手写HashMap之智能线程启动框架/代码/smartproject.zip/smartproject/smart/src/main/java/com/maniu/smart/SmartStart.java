package com.maniu.smart;


import android.content.Context;

import com.maniu.smart.obj.IModuleStart;
import com.maniu.smart.smart.SmartPriority;
import com.maniu.smart.smart.TaskManager;

/**
 * SmartStart
 *
 * 定位对外的API接口
 *
 *
 *
 * Created by conghongjie on 2018/5/23.
 */

public class SmartStart {


    /**
     * 暴露API
     */

    public static void getDefaultPriorities(String defaultPriorities){
        SmartPriority.getDefaultPriorities(defaultPriorities);
    }

    public static void setContext(Context context) {
        TaskManager.setContext(context);
    }

    public static void addModuleStart(IModuleStart moduleStart) {
        TaskManager.addModuleStart(moduleStart);
    }


    public static void startApplicationTasks() {
        TaskManager.startApplicationTasks();
    }

    public static void waitUntilApplicationTasksFinish() {
        TaskManager.waitUntilApplicationTasksFinish();
    }

    public static void startDelayTasks() {
        TaskManager.startDelayTasks();
    }





}
