package com.maniu.smartproject.module;

import com.maniu.smart.obj.AbsTask;
import com.maniu.smart.obj.ApplicationCPUTask;
import com.maniu.smart.obj.IModuleStart;
import com.maniu.smartproject.StartConstant;
import com.maniu.smartproject.Test;

import java.util.ArrayList;

/**
 * Created by conghongjie on 2018/6/5.
 */

public class VideoModule {



    public static IModuleStart videoModuleStart = new IModuleStart() {
        @Override
        public void buildTasks(ArrayList<AbsTask> tasks) {
            tasks.add(new ApplicationCPUTask(StartConstant.Video_ApplicationTask_1)
                    .addDepend(StartConstant.Article_ApplicationTask_2)
                    .setExecutor(new AbsTask.Executor() {
                        @Override
                        public void execute() {
                            Test.doJob(200);
                        }
                    })
            );
        }
    };




}
