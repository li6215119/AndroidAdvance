package com.maniu.smartproject;

/**
 * Created by conghongjie on 2018/5/24.
 */
public class StartConstant {



    /**
     * 基础库
     */
    // Hook
    public static final String CommonLib_Hook_Init = "CommonLib_Hook_Init";


    // 图片库
    public static final String CommonLib_Picture_Init = "CommonLib_Picture_Init";



    /**
     * 业务Module
     */
    // 文章
    public static final String Article_ApplicationTask_1 = "Article_ApplicationTask_1";
    public static final String Article_ApplicationTask_2 = "Article_ApplicationTask_2";
    public static final String Article_DelayTask_1 = "Article_DelayTask_1";
    public static final String Article_DelayTask_2 = "Article_DelayTask_2";

    // 聊天
    public static final String Chat_ApplicationTask_1 = "Chat_ApplicationTask_1";
    public static final String Chat_ApplicationTask_2 = "Chat_ApplicationTask_2";
    public static final String Chat_DelayTask_1 = "Chat_DelayTask_1";
    public static final String Chat_DelayTask_2 = "Chat_DelayTask_2";


    //视频
    public static final String Video_ApplicationTask_1 = "Video_ApplicationTask_1";


    /**
     * demo
     */
    public static final String Module_01 = "Module_01";
    public static final String Module_02 = "Module_02";
    public static final String Module_03 = "Module_03";
    public static final String Module_04 = "Module_04";

    public static final String Module_11 = "Module_11";
    public static final String Module_12 = "Module_12";
    public static final String Module_13 = "Module_13";
    public static final String Module_14 = "Module_14";
    public static final String Module_15 = "Module_15";


    public static final String Module_21 = "Module_21";
    public static final String Module_22 = "Module_22";
    public static final String Module_23 = "Module_23";
    public static final String Module_24 = "Module_24";
    public static final String Module_25 = "Module_25";
    public static final String Module_26 = "Module_26";


    public static final String Module_31 = "Module_31";
    public static final String Module_32 = "Module_32";
    public static final String Module_33 = "Module_33";
    public static final String Module_34 = "Module_34";


    public static final String Module_41 = "Module_41";


    public static final String Module_51 = "Module_51";
    public static final String Module_52 = "Module_52";

    public static final String Module_61 = "Module_61";
    public static final String Module_62 = "Module_62";


    public static final String Module_71 = "Module_71";
    public static final String Module_72 = "Module_72";


    public static final String Module_81 = "Module_81";
    public static final String Module_82 = "Module_82";

    public static final String Module_91 = "Module_91";


    public static final String Module_a1 = "Module_a1";
    public static final String Module_a2 = "Module_a2";
    public static final String Module_a3 = "Module_a3";
    public static final String Module_a4 = "Module_a4";

    public static final String Module_b1 = "Module_b1";
    public static final String Module_b2 = "Module_b2";
    public static final String Module_b3 = "Module_b3";
    public static final String Module_b4 = "Module_b4";
    public static final String Module_b5 = "Module_b5";


    public static final String Module_c1 = "Module_c1";
    public static final String Module_c2 = "Module_c2";
    public static final String Module_c3 = "Module_c3";
    public static final String Module_c4 = "Module_c4";
    public static final String Module_c5 = "Module_c5";
    public static final String Module_c6 = "Module_c6";


    public static final String Module_d1 = "Module_d1";
    public static final String Module_d2 = "Module_d2";
    public static final String Module_d3 = "Module_d3";
    public static final String Module_d4 = "Module_d4";


    public static final String Module_e1 = "Module_e1";


    public static final String Module_f1 = "Module_f1";
    public static final String Module_f2 = "Module_f2";

    public static final String Module_g1 = "Module_g1";
    public static final String Module_g2 = "Module_g2";


    public static final String Module_h1 = "Module_h1";
    public static final String Module_h2 = "Module_h2";


    public static final String Module_i1 = "Module_i1";
    public static final String Module_i2 = "Module_i2";

    public static final String Module_j1 = "Module_j1";


}
