package com.maniu.smartproject.module;



import com.maniu.smart.obj.AbsTask;
import com.maniu.smart.obj.ApplicationCPUTask;
import com.maniu.smart.obj.DelayCPUTask;
import com.maniu.smart.obj.IModuleStart;
import com.maniu.smartproject.StartConstant;
import com.maniu.smartproject.Test;

import java.util.ArrayList;

/**
 * Created by conghongjie on 2018/6/5.
 */

public class ArticleModule {


    public static IModuleStart articleModuleStart = new IModuleStart() {
        @Override
        public void buildTasks(ArrayList<AbsTask> tasks) {
            tasks.add(new ApplicationCPUTask(StartConstant.Article_ApplicationTask_1)
                    .addDepend(StartConstant.Module_23)
                    .setExecutor(new AbsTask.Executor() {
                        @Override
                        public void execute() {
                            Test.doJob(200);
                        }
                    })
            );
            tasks.add(new ApplicationCPUTask(StartConstant.Article_ApplicationTask_2)
                    .setExecutor(new AbsTask.Executor() {
                        @Override
                        public void execute() {
                            Test.doJob(100);
                            Test.doSleep(500);
                            Test.doJob(100);
                        }
                    })
            );
            tasks.add(new DelayCPUTask(StartConstant.Article_DelayTask_1)
                    .setExecutor(new AbsTask.Executor() {

                        @Override
                        public void execute() {
                            Test.doJob(200);
                        }
                    })
            );
            tasks.add(new DelayCPUTask(StartConstant.Article_DelayTask_2)
                    .addDepend(StartConstant.Article_DelayTask_1)
                    .setExecutor(new AbsTask.Executor() {
                        @Override
                        public void execute() {
                            Test.doJob(100);
                            Test.doSleep(500);
                            Test.doJob(100);
                        }
                    })
            );
        }
    };





}
