package com.maniu.fileserchar;

import java.io.File;
import java.util.LinkedList;

public class MyClass {


/*传一个数组
归并排序
* */
    public static  void mergeSort(int[] nums) {
        int[] tmpArray = new int[nums.length];

    }

    public static void mSort(int[] nums, int[] tmps, int left, int right) {
        int center;
        if (left < right) {
            center = (left + right) / 2;
//            分
            mSort(nums, tmps, left, center);
            mSort(nums, tmps, center + 1, right);
//            排序
            merge(nums, tmps, left, center + 1, right);

        }

    }
//    希尔排序  桶排序    性能最优   归并排序    其次
//     递归    ----》
    // 空间归并
    public static void merge(int[] nums, int[] tmps, int lpos, int rpos, int rightEnd) {
        int i, leftEnd, numElements, tmpPos;
        leftEnd = rpos - 1;
        tmpPos = lpos;
        numElements = rightEnd - lpos + 1;
        while (lpos <= leftEnd && rpos <= rightEnd) {
            if (nums[lpos] <= nums[rpos])
                tmps[tmpPos++] = nums[lpos++];
            else
                tmps[tmpPos++] = nums[rpos++];
        }
        while (lpos <= leftEnd)
            tmps[tmpPos++] = nums[lpos++];
        while (rpos <= rightEnd)
            tmps[tmpPos++] = nums[rpos++];
        for (i = 0; i < numElements; i++, rightEnd--)
            nums[rightEnd] = tmps[rightEnd];
    }



//filename  MainActivity.java guangduSeacher -一个方法
    public static  void guangduSeacher(String parentDir,String filename) {
//堆区
        LinkedList<File> linkedList = new LinkedList<>();
        File filelist[] = new File(parentDir).listFiles();
        for (File f : filelist) {
//            第一层文件夹
            if (f.isDirectory()) {
                linkedList.offer(f);
            }else {
                if (f.getName().contains(filename)) {
                    System.out.println(f.getAbsolutePath());
                }
            }
        }
//       遍历之前的队列  性能  广度 要好一些

        while (!linkedList.isEmpty()) {
//
            File fileTemp = linkedList.poll();
            File[] fileListTemp=fileTemp.listFiles();
            if (fileListTemp == null) {
                continue;
            }
            for (File f : fileListTemp) {
                if (f.isDirectory()) {
                    linkedList.offer(f);
                }else {
                    if (f.getName().contains(filename)) {
                        System.out.println(f.getAbsolutePath());
                    }
                }
            }
        }
    }
    public static void main(String[] args) {
        File file = new File(System.getProperty("user.dir"));
        System.out.println("父目录"+file.getAbsolutePath());


        long start = System.currentTimeMillis();

        guangduSeacher(file.getAbsolutePath(), "MainActivity");
        System.out.println("广度优先搜索  :"+(System.currentTimeMillis() - start));
        start = System.currentTimeMillis();
        FindFile(file.getAbsolutePath(), "MainActivity");
        System.out.println("深度优先搜索  :"+(System.currentTimeMillis() - start));
    }
//内存稳定  广度优先

//     内存
//    时间是差不多
//    写代码    不好  递归次数不能把控    基本是没问题    文件
    public static  void FindFile (String parentDir,String filename) {
        File file = new File(parentDir);//文件路径关联
        File filelist[] = file.listFiles();//定义一个列表接收file.listFiles搜索出来的所有文件以及文件夹
        for (int i = 0; i < filelist.length; i++) {//遍历filelist里面的内容
            if (filelist[i].isFile()) {//判断如果是文件

                if(filelist[i].getName().contains(filename)) {// 判断关键字是否在文件名里
//                    System.out.println(filelist[i].getAbsolutePath());//如果是的话就打印它的文件名
                }
            }else {
                FindFile(filelist[i].getAbsolutePath(),filename); //如果文件夹，就递归执行FindFile方法
            }
        }
    }



}
