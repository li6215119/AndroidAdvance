package com.maniu.maniufix;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import java.io.File;
import java.lang.reflect.Method;
// 8.0 google    30%
public class MainActivity extends AppCompatActivity {
//     预测   解决
//
    DexManager dexManager = new DexManager(this);
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.result);
        verifyStoragePermissions(this);

    }
    public   void verifyStoragePermissions(Activity activity) {
        int REQUEST_EXTERNAL_STORAGE = 1;
        String[] PERMISSIONS_STORAGE = {
                "android.permission.READ_EXTERNAL_STORAGE",
                "android.permission.WRITE_EXTERNAL_STORAGE" };
        try {
            //检测是否有写的权限
            int permission = ActivityCompat.checkSelfPermission(activity,
                    "android.permission.WRITE_EXTERNAL_STORAGE");
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // 没有写的权限，去申请写的权限，会弹出对话框
                ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE,REQUEST_EXTERNAL_STORAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void caclutor(View view) {
//   so   资源
        Caclutor caclutor = new Caclutor();

        caclutor.caculator();
        Caclutor caclutor1 = new Caclutor();
        Caclutor caclutor2 = new Caclutor();
        Caclutor caclutor3 = new Caclutor();
        textView.setText("结果  "+caclutor3.caculator());
//线上bug是没法预先知道的吧   问题  小问题 --》大问题
    }
//每次都修复 -----》 自动做
    public void fix(View view) {
        try {
            File file = new File(Environment.getExternalStorageDirectory(), "out.dex");
            dexManager.load(file);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
