package com.maniu.maniufix.web;

import com.maniu.maniufix.Replace;

public class Caclutor {
    @Replace(clazz = "com.maniu.maniufix.Caclutor",method = "caculator")
    public int caculator()
    {
        int b = 300;
        int c = 600;
        return c / b;
    }

}
