package com.maniu.maniufix;

public class Caclutor {
//
    public int caculator()
    {
        throw new RuntimeException("app崩溃了");
    }
}
