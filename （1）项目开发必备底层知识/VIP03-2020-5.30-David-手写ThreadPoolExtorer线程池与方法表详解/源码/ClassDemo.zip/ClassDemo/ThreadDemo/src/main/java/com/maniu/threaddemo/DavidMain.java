package com.maniu.threaddemo;

public class DavidMain {
    public static void main(String[] args) {
        System.out.printf("=====");
    }
}
