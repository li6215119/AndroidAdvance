package com.maniu.threaddemo;

import java.util.concurrent.locks.Lock;

public class LockManiu implements Runnable {
    private static int a = 0;
    private Object lock = new Object();
    private byte[] lock1 = new byte[1];
    //synchronized   ----> 当前的对象
    public   synchronized   void run() {
        lock.notifyAll();
        for (int i = 0; i < 100000; i++) {
            incre();
        }
    }
//synchronized   切入口  速度


//琐升级
    public     void incre() {
        a++;
//        10000
        synchronized (lock) {
//            同步代码
        }

    }

    public static void main(String[] args) throws InterruptedException {
        LockManiu lockManiu = new LockManiu();
        LockManiu lockManiu1 = new LockManiu();
        Thread thread = new Thread(lockManiu);
        Thread thread2 = new Thread(lockManiu1);
        thread.start();
        thread2.start();
        thread2.join();
        thread.join();
        System.out.printf("a : " + a);
    }
}
