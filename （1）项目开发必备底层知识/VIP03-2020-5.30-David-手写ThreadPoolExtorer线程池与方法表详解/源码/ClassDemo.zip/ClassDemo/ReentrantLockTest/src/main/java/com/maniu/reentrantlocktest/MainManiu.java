package com.maniu.reentrantlocktest;

import java.util.concurrent.locks.LockSupport;

public class MainManiu {
    static Maniu1ReentrantLock maniu1ReentrantLock = new Maniu1ReentrantLock();
    public static void main(String[] args) {
        Throwable throwable;
        throwable.();
        new Thread() {
            @Override
            public void run() {
                LockSupport.park();
//走到了这里
                try {
                    sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


            }
        }.start();


        LockSupport.park();

    }
}
