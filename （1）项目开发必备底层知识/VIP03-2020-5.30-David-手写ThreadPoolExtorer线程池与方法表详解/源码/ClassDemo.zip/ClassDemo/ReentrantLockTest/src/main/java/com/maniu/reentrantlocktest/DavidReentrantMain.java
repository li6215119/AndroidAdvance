package com.maniu.reentrantlocktest;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public class DavidReentrantMain {
    static int ii = 0;
    static DavidReentrantLock lock= new DavidReentrantLock();
    ReentrantLock reentrantLock;
    public static void main(String[] args) throws InterruptedException {
        for(int i=0;i<5;i++){
            Thread tt=new Thread(){
                @Override
                public void run() {
                    for (int i = 0; i < 1000000; i++) {
//                        不会被阻塞住   //2
                        lock.lock();
//
                        ii++;
                        lock.unlock();
                    }
                    }
            };
            tt.start();
            tt.join();
        }
        System.out.println(ii);
    }
}
