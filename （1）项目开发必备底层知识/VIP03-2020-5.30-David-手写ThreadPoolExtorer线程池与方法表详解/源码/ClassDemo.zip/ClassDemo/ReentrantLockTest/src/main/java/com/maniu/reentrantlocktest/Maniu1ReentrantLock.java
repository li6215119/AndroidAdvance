package com.maniu.reentrantlocktest;

public class Maniu1ReentrantLock {
    volatile int status = 0;
    void lock() {
//
        while (!comparenAndSet(0, 1)) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    void unlock() {

    }

    boolean comparenAndSet(int excepect, int newValue) {
        return false;
    }
}
