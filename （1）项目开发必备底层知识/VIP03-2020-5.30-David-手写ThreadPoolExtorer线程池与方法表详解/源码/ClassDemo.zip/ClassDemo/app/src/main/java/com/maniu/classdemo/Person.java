package com.maniu.classdemo;

public class Person {
    public void get() {

    }
}
