package com.maniu.classdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.BitmapFactory;
import android.os.Bundle;

import java.util.concurrent.atomic.AtomicInteger;


public class MainActivity extends AppCompatActivity {
    private static  volatile int i = 0;
    AtomicInteger atomicInteger = new AtomicInteger();
    protected  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //
        Person person = new Person();

        /**
         * 000b: new-instance v0, Singleton // type@0000
         *
         *  0010: sput-object v0, Singleton.singleton:LSingleton; // field@0000
         */
        person.getClass();
        atomicInteger.incrementAndGet();

//
        person.get();
//        classSize  --->  多大
//        final Singleton singleton= Singleton.getInstance();
        new Thread(){
            @Override
            public void run() {
                Singleton  singleton1 = Singleton.getInstance();
                singleton1.getPerson();
            }
        }.start();
    }

}
