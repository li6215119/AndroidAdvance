public class Demo {
    public    void   foo() {
        int a = 100;
    }
}
//Demo.java-->Demo.class---->dex文件

//synchronized   ----》synchronized 不会有
//   字节码指令