package com.maniu.classdemo;

public class UserManger {
    private    static   UserManger ourInstance ;
    private UserManger() {
    }

    public static UserManger getInstance(){
        if (ourInstance == null) {
            synchronized (UserManger.class) {
                if (ourInstance == null) {
                    ourInstance = new UserManger();
                }
            }
        }
        return ourInstance;
    }
}
