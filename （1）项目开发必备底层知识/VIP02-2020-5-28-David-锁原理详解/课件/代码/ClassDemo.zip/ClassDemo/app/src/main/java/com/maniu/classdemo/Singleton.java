package com.maniu.classdemo;

public class Singleton {
      public  volatile  static  Singleton singleton;
              private Singleton() {};
             public static Singleton getInstance() {
//                 singleton   位空
                 if (singleton == null) {
                         synchronized (singleton) {
                                 if (singleton == null) {
                                        singleton = new Singleton();

                                        //new  指令    ====》 new-instance
                                     }
                            }
                     }
                return singleton;
             }

    public void getPerson() {

    }
 }