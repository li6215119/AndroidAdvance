package com.maniu.threaddemo;

import java.util.List;

public interface IThreadPool {
    //加入任务
    void execute(Runnable task);

    //加入任务
    void execute(Runnable[] tasks);

    //加入任务
    void execute(List<Runnable> tasks);

    //销毁线程
    void destroy();
}
