package com.maniu.threaddemo;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

public class ThreadDavid {
    static volatile AtomicInteger num = new AtomicInteger();
    public  synchronized static void main(String[] args) {
        ReentrantLock reentrantLock = new ReentrantLock();
        IThreadPool t = ThreadPoolImpl.getThreadPool(20);
        ConcurrentHashMap hashMap;
        List<Runnable> taskList = new ArrayList<Runnable>();
        for (int i = 0; i < 100; i++) {
            taskList.add(new Task(i, "线程  " + i));
        }
        t.execute(taskList);
    }

    static class Task implements Runnable, Comparable<Task> {
        private int property;
        public static final int LOW = 1;
        public static final int NORMAL = 2;
        public static final int HIGH = 3;
        private static volatile int i = 1;
        private String name;
        public Task( ) {
        }
        public Task(int property,String name) {
            this.name = name;
            this.property = property;
        }

        public int getProperty() {
            return property;
        }

        @Override
        public void run() {
            System.out.println("当前处理的线程:" + name+ " 执行任务" );
        }

        @Override
        public int compareTo(Task o) {
            return property- o.getProperty() ;
        }
    }

}
