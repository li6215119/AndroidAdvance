package com.maniu.reentrantlocktest;

public class Lock1 {
    volatile int status = 0;

//    void lock() {
//        while (!compareAndSet(0, 1)) {
//
//        }
//    }
}
