package com.maniu.reentrantlocktest;

import java.util.concurrent.locks.LockSupport;

public class _02Park {
    public static void main(String[] args) throws InterruptedException {
        Thread thread = new Thread() {
            @Override
            public void run() {
                System.out.println("线程t1");
                LockSupport.park();
                System.out.println("线程睡眠");
            }
        };
        thread.setName("t1");
        thread.start();
        Thread.sleep(3000);
        System.out.println("main----1");
        LockSupport.unpark(thread);
    }


}
