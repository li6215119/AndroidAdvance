package com.maniu.proxy;
//接口
public interface HelloInterface {
    void sayHello();
}
