package com.mnvipmemoryopt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    public static int Flag = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 内存的基础；
        a();
        // UI线程  拥有 java虚拟机栈
        // java虚拟机栈由栈帧组成；一个方法就对应一个栈帧；
        // 内存抖动 内存泄漏：应该被回收的对象 没有被回收；
        // 关注内存3个主要点
        // 1：代码在jvm中到底是怎么存在的（栈帧到底什么关系）
        // 2：某个对象在内存中到底占用多少内存
        // 3：某个对象的生命周期；线程，application，

        A a = new A();

    }

    public void a(){

        // 本地方法 变量
        int b = 1;
        int c = 2;
        int d = b+c;
        A aaa = new A();// a 里面引用b  - c -d -e
        A aa = new A();
        // 长生命周期 引用了一个 短神明周期对象；
        int k = c();
//        int kk = d();
    }

    private int c() {
        return 0;
    }

    public class A{
       private int a =1;  // 4个字节
       private String b = "aaaaaaaaaa"; // 8个字节
       private A aa = new A(); // 8个字节
        // 对象头 8字节
        // 内存条  一个一个电子器件组成；一个电子器件就代表1位；
//        private byte[] bytes = new byte[1024*1024];
    }

//    private class MNThread{
//        private JavaVirtual jv;
//        private LocalVirtual lv;
//        private ProCount pc;
//    }
//
//    private class JavaVirtual{
//        private List<Frame> frames;
//    }
//
//    private class Frame{
//        private int[] localVaris;
//        private Caozuoshu czs;
//        private MethodReturn mr;
//
//    }

}
