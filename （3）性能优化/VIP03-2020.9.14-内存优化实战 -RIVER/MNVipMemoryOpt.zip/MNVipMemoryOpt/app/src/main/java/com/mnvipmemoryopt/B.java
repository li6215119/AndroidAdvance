package com.mnvipmemoryopt;

public class B {

    private C c = new C();

}
