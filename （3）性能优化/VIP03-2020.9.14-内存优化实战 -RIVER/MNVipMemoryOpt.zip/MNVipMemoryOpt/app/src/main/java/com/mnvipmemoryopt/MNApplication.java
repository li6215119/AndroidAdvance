package com.mnvipmemoryopt;

import android.app.Application;

public class MNApplication extends Application {

    public static MainActivity.A a = null;

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
