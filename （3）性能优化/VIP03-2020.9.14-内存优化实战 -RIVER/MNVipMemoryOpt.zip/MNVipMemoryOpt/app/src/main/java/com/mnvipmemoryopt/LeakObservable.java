package com.mnvipmemoryopt;

import java.util.ArrayList;
import java.util.List;

public class LeakObservable implements LeakObserver{

    // 本类相当于迷蒙；

    private static LeakObservable instance;

    public static LeakObservable getInstance(){
        if(instance == null){
            instance = new LeakObservable();
        }
        return instance;
    }

    private LeakObservable(){}

    private List<LeakObserver> list = new ArrayList<>();

    public void register(LeakObserver observer){
        list.add(observer);
    }

    public void unRegister(LeakObserver observer){
        list.remove(observer);
    }

    @Override
    public void handle() {
//        for(int i=0;)
        // do nothing in this example;
        // for循环 直接循环list中的所有订阅者，然后调用handle方法发送文章；
        // 系统级别的泄漏：
        // 考虑点：api的判断，是否支持反射；基础判null处理；
    }

}
