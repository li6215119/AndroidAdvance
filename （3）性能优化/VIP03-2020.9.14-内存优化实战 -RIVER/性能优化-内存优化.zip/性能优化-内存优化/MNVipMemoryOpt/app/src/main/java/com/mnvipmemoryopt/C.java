package com.mnvipmemoryopt;

public class C {

    private int a = 1;

}
