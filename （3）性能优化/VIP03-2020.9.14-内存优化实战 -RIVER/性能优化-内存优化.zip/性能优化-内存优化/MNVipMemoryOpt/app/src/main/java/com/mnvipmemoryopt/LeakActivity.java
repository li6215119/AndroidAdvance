package com.mnvipmemoryopt;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LeakActivity extends AppCompatActivity implements LeakObserver{

    // hprof-conv .\memory-20200914T193016.hprof 1.hprof
    // https://www.eclipse.org/mat/downloads.php
    // 观察者模式；
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leak);
        setViewListener();
    }

    private void setViewListener(){
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LeakObservable.getInstance().register(LeakActivity.this);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LeakObservable.getInstance().unRegister(this);
    }

    @Override
    public void handle() {

    }


}
