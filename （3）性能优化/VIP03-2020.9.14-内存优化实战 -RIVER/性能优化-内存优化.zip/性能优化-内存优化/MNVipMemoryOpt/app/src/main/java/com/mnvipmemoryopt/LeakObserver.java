package com.mnvipmemoryopt;

public interface LeakObserver {

    // 是不是就代表 微信？
    void handle();// 这个方法就是接受订阅消息的地方；

}
